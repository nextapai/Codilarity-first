const express = require('express')
const router = express.Router()
const passport = require('passport');

module.exports =  isAuthenticated = (req, res, next) =>{
    req.user ? next() : res.send("Failed")
}


router.get("/google", passport.authenticate('google', { scope: ['email', 'profile'], prompt: "select_account" }))

router.get("/googleCallback", passport.authenticate('google', {
    successRedirect: "/UI/main",
    failureRedirect: "/auth/failure"
}))

router.get("/failure", (req, res) => {
    res.send("<h1>Access Denied for this email id</h1> <a href='/Ui/index'>BACK</a>")
})

router.get("/logout", (req, res) => {
    req.logout();
    req.session.destroy()
    res.redirect("/UI/index");
})

module.exports = router