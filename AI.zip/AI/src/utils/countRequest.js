const User = require("../models/user")

const addRequest = (req, res, next) => {
    var userInstance = req.user
    var count = userInstance.reqCount + 1
    console.log(userInstance.reqCount)
    User.findOneAndUpdate({ _id: userInstance._id }
        , { $set: { reqCount: count } }
        , function (err, doc) {
            if (err) {
                res.send("Soory")
            } else {
                next()
            }
        });

}

module.exports = addRequest