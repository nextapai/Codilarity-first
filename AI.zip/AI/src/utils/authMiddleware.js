
const isAuthenticated = (req, res, next) =>{
    req.user ? next() : res.send("<h1>You need to Login to Workspace</h1> <a href='/Ui/login'>LOGIN HERE</a>")
}

module.exports = isAuthenticated